SELECT * FROM gg_mmr_cashflow


